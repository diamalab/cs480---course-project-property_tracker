package user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.domain.User;

public class InitializeDao {
	
	public void initDB() {
		Statement statement;
		PreparedStatement preparedStatement;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/bookstore?"
					+ "user=root&password=HetanN123!");
		    
			// Statements allow to issue SQL queries to the database
			statement = connect.createStatement();
			statement.executeUpdate("DROP TABLE IF EXISTS Student");
			
			String sqlstmt = "CREATE TABLE IF NOT EXISTS Student " +
							 "(id INTEGER not NULL AUTO_INCREMENT, " +
							 " Name VARCHAR(20), " +
							 " Address VARCHAR(50), " +
							 " Status VARCHAR(10), " +
							 " PRIMARY KEY ( id ))";
			statement.executeUpdate(sqlstmt);
			
			preparedStatement = connect.prepareStatement("insert into Student(Name, Address, Status) values (?, ?, ?)");
			preparedStatement.setString(1, "Shiyong Lu");
			preparedStatement.setString(2, "123 Main Street, Troy, MI 48083");
			preparedStatement.setString(3, "Senior");
			preparedStatement.executeUpdate();
			
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
