package property.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import property.domain.Property;

public class PropertyDao {
	/*
	 * INSERT/ADD
	 */
	public void add(Property property) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "insert into Property values(?,?,?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setInt(1,property.getPropertyKey());
		    preparestatement.setString(2,property.getAddress());
		    preparestatement.setString(3,property.getCity());
		    preparestatement.setString(4,property.getState());
		    preparestatement.setString(5,property.getListingDate());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * READ
	 */
	public Property read(String Address) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Property property = new Property();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
							+ "user=root&password=HetanN123!");
			
			
			String sql = "select * from Property where Address=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			preparestatement.setString(1,Address);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String theProperty = resultSet.getString("Address");
		    	if(theProperty.equals(Address)){
		    		property.setPropertyKey(resultSet.getInt("PropertyKey"));
		    		property.setAddress(resultSet.getString("Address"));
		    		property.setCity(resultSet.getString("City"));
		    		property.setState(resultSet.getString("State"));
		    		property.setListingDate(resultSet.getString("ListingDate"));
		    	}
		    }
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		return property;
	}
	
	/*
	 * UPDATE
	 */
	public void update(int PropertyKey, String Address) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "update Property set Address=? where PropertyKey=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setString(1, Address);
			preparestatement.setInt(2, PropertyKey);
		    preparestatement.executeUpdate();
		    System.out.println("Row updated!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * DELETE
	 */
	public void delete(int PropertyKey) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "delete from Property where PropertyKey=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setInt(1, PropertyKey);
		    preparestatement.executeUpdate();
		    System.out.println("Row deleted!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
