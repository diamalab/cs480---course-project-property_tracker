package property.service;

import property.dao.PropertyDao;
import property.domain.Property;
import user.service.UserException;

public class PropertyService {
	private PropertyDao propertyDao = new PropertyDao();
	
	/*
	 * INSERT
	 */
	public void insert(Property form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		Property property = propertyDao.read(form.getAddress());
		if(property.getAddress() !=null && property.getAddress().equals(form.getAddress())) throw
		new UserException("This property has been registered!");
		propertyDao.add(form);
	}
	
	/*
	 * READ
	 */
	public void readrow(Property form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Property property = propertyDao.read(form.getAddress());
		if(property.getAddress()==null) throw new UserException("The address is not in the database");
		System.out.println(property);
	}
	
	/*
	 * UPDATE
	 */
	public void updaterow(int PropertyKey, String Address) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		propertyDao.update(PropertyKey, Address);
	}
	
	/*
	 * DELETE
	 */
	public void deleterow(int PropertyKey) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		propertyDao.delete(PropertyKey);
	}
}
