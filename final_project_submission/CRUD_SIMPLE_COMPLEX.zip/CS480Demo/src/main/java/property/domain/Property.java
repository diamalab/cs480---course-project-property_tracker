package property.domain;

public class Property {
	/*
	 * Correspond to the property table
	 */
	
	private int PropertyKey;  // column name
	private String Address;  // column name
	private String City;  // column name
	private String State;  // column name
	private String ListingDate; // column name
	
	// generate getters and setters

	public int getPropertyKey() {
		return PropertyKey;
	}

	public void setPropertyKey(int PropertyKey) {
		this.PropertyKey = PropertyKey;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String Address) {
		this.Address = Address;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String City) {
		this.City = City;
	}
	
	public String getState() {
		return State;
	}

	public void setState(String State) {
		this.State = State;
	}
	
	public String getListingDate() {
		return ListingDate;
	}

	public void setListingDate(String ListingDate) {
		this.ListingDate = ListingDate;
	}
	
	@Override
	public String toString() {
		return "Property [ PropertyKey=" + PropertyKey + ", Address="
				+ Address + ", City=" + City + ", State=" + State + ", listingDate=" + ListingDate +"]";
	}
}
