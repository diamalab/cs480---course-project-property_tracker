package commercial.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import commercial.domain.Commercial;

public class CommercialDao {
	/*
	 * INSERT/ADD
	 */
	public void add(Commercial commercial) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "insert into Commercial values(?,?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setInt(1,commercial.getCommercialKey());
		    preparestatement.setString(2,commercial.getCommercialType());
		    preparestatement.setInt(3,commercial.getComBrokerKey());
		    preparestatement.setInt(4,commercial.getComReportKey());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * READ
	 */
	public Commercial read(String CommercialType) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Commercial commercial = new Commercial();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
							+ "user=root&password=HetanN123!");
			
			
			String sql = "select * from Commercial where CommercialType=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			preparestatement.setString(1,CommercialType);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String theCommercial = resultSet.getString("CommercialType");
		    	if(theCommercial.equals(CommercialType)){
		    		commercial.setCommercialKey(resultSet.getInt("CommercialKey"));
		    		commercial.setCommercialType(resultSet.getString("CommercialType"));
		    		commercial.setComBrokerKey(resultSet.getInt("ComBrokerKey"));
		    		commercial.setComReportKey(resultSet.getInt("ComReportKey"));
		    	}
		    }
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		return commercial;
	}
	
	/*
	 * UPDATE
	 */
	public void update(int CommercialKey, String CommercialType) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "update Commercial set CommercialType=? where CommercialKey=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setString(1, CommercialType);
			preparestatement.setInt(2, CommercialKey);
		    preparestatement.executeUpdate();
		    System.out.println("Row updated!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * DELETE
	 */
	public void delete(int CommercialKey) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "delete from Commercial where CommercialKey=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setInt(1, CommercialKey);
		    preparestatement.executeUpdate();
		    System.out.println("Row deleted!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
