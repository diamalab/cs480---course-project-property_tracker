package commercial.domain;

public class Commercial {
	/*
	 * Correspond to the property table
	 */
	
	private int CommercialKey;  // column name
	private String CommercialType;  // column name
	private int ComBrokerKey;  // column name
	private int ComReportKey;  // column name
	
	// generate getters and setters

	public int getCommercialKey() {
		return CommercialKey;
	}

	public void setCommercialKey(int CommercialKey) {
		this.CommercialKey = CommercialKey;
	}

	public String getCommercialType() {
		return CommercialType;
	}

	public void setCommercialType(String CommercialType) {
		this.CommercialType = CommercialType;
	}

	public int getComBrokerKey() {
		return ComBrokerKey;
	}

	public void setComBrokerKey(int ComBrokerKey) {
		this.ComBrokerKey = ComBrokerKey;
	}
	
	public int getComReportKey() {
		return ComReportKey;
	}

	public void setComReportKey(int ComReportKey) {
		this.ComReportKey = ComReportKey;
	}
	
	@Override
	public String toString() {
		return "Commercial [ CommercialKey=" + CommercialKey + ", CommercialType="
				+ CommercialType + ", ComBrokerKey=" + ComBrokerKey + ", ComReportKey=" + ComReportKey +"]";
	}
}
