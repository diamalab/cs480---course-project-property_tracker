package commercial.service;

import commercial.dao.CommercialDao;
import commercial.domain.Commercial;
import user.service.UserException;

public class CommercialService {
	private CommercialDao commercialDao = new CommercialDao();
	
	/*
	 * INSERT
	 */
	public void insert(Commercial form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		commercialDao.add(form);
	}
	
	/*
	 * READ
	 */
	public void readrow(Commercial form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Commercial commercial = commercialDao.read(form.getCommercialType());
		if(commercial.getCommercialType()==null) throw new UserException("This commercial type is not in the database");
		System.out.println(commercial);
	}
	
	/*
	 * UPDATE
	 */
	public void updaterow(int CommercialKey, String CommercialType) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		commercialDao.update(CommercialKey, CommercialType);
	}
	
	/*
	 * DELETE
	 */
	public void deleterow(int CommercialKey) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		commercialDao.delete(CommercialKey);
	}
}
