package commercial.service;

public class CommercialException extends Exception {

	public CommercialException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommercialException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
