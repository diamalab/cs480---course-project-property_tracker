package commercial.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import commercial.dao.CommercialDao;
import commercial.domain.Commercial;
import commercial.service.CommercialService;
import user.service.UserException;

/**
 * Servlet implementation class CommercialServletRead
 */

public class CommercialServletRead extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommercialServletRead() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Map<String, String> form = new HashMap<String,String>();
		CommercialDao propertydao = new CommercialDao();
		Commercial commercial = null;
		try {
			commercial = propertydao.read(request.getParameter("CommercialType"));
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		CommercialService commercialservice = new CommercialService();		
		if(commercial.getCommercialType()!=null){
			try {
				commercialservice.readrow(commercial);
				request.getSession().setAttribute("session_user", commercial);
				
				request.getRequestDispatcher("/jsps/commercial/update.jsp").forward(request, response);
			} catch (ClassNotFoundException | UserException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
			} 
		}
		else{
			request.setAttribute("msg", "You need to register data first");
			request.getRequestDispatcher("/jsps/user/login.jsp").forward(request, response);
		}
	}
}
