package broker.domain;

public class Broker {
	/*
	 * Correspond to the property table
	 */
	
	private int ComBrokerKey;  // column name
	private String Name;  // column name
	private String Phone;  // column name
	private String Email;  // column name
	
	// generate getters and setters

	public int getComBrokerKey() {
		return ComBrokerKey;
	}

	public void setComBrokerKey(int ComBrokerKey) {
		this.ComBrokerKey = ComBrokerKey;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}
	
	public String getPhone() {
		return Phone;
	}

	public void setPhone(String Phone) {
		this.Phone = Phone;
	}
	
	public String getEmail() {
		return Email;
	}

	public void setEmail(String Email) {
		this.Email = Email;
	}
	
	@Override
	public String toString() {
		return "CommercialBroker [ ComBrokerKey=" + ComBrokerKey + ", Name="
				+ Name + ", Phone=" + Phone + ", Email=" + Email +"]";
	}
}
