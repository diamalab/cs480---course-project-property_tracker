package broker.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import broker.domain.Broker;

public class BrokerDao {
	/*
	 * INSERT OR ADD
	 */
	public void add(Broker broker) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "insert into CommercialBroker values(?,?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setInt(1,broker.getComBrokerKey());
		    preparestatement.setString(2,broker.getName());
		    preparestatement.setString(3,broker.getPhone());
		    preparestatement.setString(4,broker.getEmail());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * READ
	 */
	public Broker read(String Name) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Broker broker = new Broker();
		try {
		
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
							+ "user=root&password=HetanN123!");
			
			
			String sql = "select * from CommercialBroker where Name=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			preparestatement.setString(1,Name);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String theProperty = resultSet.getString("Name");
		    	if(theProperty.equals(Name)){
		    		broker.setComBrokerKey(resultSet.getInt("ComBrokerKey"));
		    		broker.setName(resultSet.getString("Name"));
		    		broker.setPhone(resultSet.getString("Phone"));
		    		broker.setEmail(resultSet.getString("Email"));
		    	}
		    }
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		return broker;
	}
	
	/*
	 * UPDATE
	 */
	public void update(int ComBrokerKey, String Name) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "update CommercialBroker set Name=? where ComBrokerKey=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setString(1, Name);
			preparestatement.setInt(2, ComBrokerKey);
		    preparestatement.executeUpdate();
		    System.out.println("Row updated!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * DELETE
	 */
	public void delete(int ComBrokerKey) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/PropertyTracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "delete from CommercialBroker where ComBrokerKey=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setInt(1, ComBrokerKey);
		    preparestatement.executeUpdate();
		    System.out.println("Row deleted!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
