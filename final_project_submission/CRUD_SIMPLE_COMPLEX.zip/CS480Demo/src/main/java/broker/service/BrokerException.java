package broker.service;

public class BrokerException extends Exception {

	public BrokerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BrokerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
