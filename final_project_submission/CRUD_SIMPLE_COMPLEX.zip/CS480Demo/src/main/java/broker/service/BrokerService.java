package broker.service;

import broker.dao.BrokerDao;
import broker.domain.Broker;
import user.service.UserException;

public class BrokerService {
	private BrokerDao brokerDao = new BrokerDao();
	
	/*
	 * INSERT
	 */
	public void insert(Broker form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		Broker broker = brokerDao.read(form.getName());
		if(broker.getName() !=null && broker.getName().equals(form.getName())) throw
		new UserException("This property has been registered!");
		brokerDao.add(form);
	}

	/*
	 * READ
	 */
	public void readrow(Broker form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Broker broker = brokerDao.read(form.getName());
		if(broker.getName()==null) throw new UserException("The address is not in the database");
		System.out.println(broker);
	}
	
	/*
	 * UPDATE
	 */
	public void updaterow(int comBrokerKey, String Name) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		brokerDao.update(comBrokerKey, Name);
	}
	
	/*
	 * DELETE
	 */
	public void deleterow(int comBrokerKey) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		brokerDao.delete(comBrokerKey);
	}
}
