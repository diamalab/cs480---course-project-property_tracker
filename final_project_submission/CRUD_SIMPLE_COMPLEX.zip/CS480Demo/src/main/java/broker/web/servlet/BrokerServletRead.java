package broker.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import broker.dao.BrokerDao;
import broker.domain.Broker;
import broker.service.BrokerService;
import user.service.UserException;

/**
 * Servlet implementation class BrokerServletRead
 */

public class BrokerServletRead extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BrokerServletRead() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Map<String, String> form = new HashMap<String,String>();
		BrokerDao brokerdao = new BrokerDao();
		Broker broker = null;
		try {
			broker = brokerdao.read(request.getParameter("Name"));
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		BrokerService brokerservice = new BrokerService();		
		if(broker.getName()!=null){
			try {
				brokerservice.readrow(broker);
				request.getSession().setAttribute("session_user", broker);
				
				request.getRequestDispatcher("/jsps/broker/update.jsp").forward(request, response);
			} catch (ClassNotFoundException | UserException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
			} 
		}
		else{
			request.setAttribute("msg", "You need to register data first");
			request.getRequestDispatcher("/jsps/user/login.jsp").forward(request, response);
		}
	}
}