package broker.domain;

public class Broker {
	/*
	 * Correspond to the property table
	 */
	
	private int commercial_broker_key;  // column name
	private String name;  // column name
	private String phone;  // column name

	// generate getters and setters

	public int getCommercialBrokerKey() {
		return commercial_broker_key;
	}

	public void setCommercialBrokerKey(int commercial_broker_key) {
		this.commercial_broker_key = commercial_broker_key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "Broker [ commercial_broker_key=" + commercial_broker_key + ", name="
				+ name + ", phone=" + phone +"]";
	}
}
