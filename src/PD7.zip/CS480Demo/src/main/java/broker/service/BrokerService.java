package broker.service;

import broker.dao.BrokerDao;
import broker.domain.Broker;
import user.service.UserException;

public class BrokerService {
	private BrokerDao brokerDao = new BrokerDao();
	
	/*
	 * INSERT
	 */
	public void insert(Broker form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		Broker broker = brokerDao.read(form.getName());
		if(broker.getName() !=null && broker.getName().equals(form.getName())) throw
		new UserException("This property has been registered!");
		brokerDao.add(form);
	}

	/*
	 * READ
	 */
	public void readrow(Broker form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Broker broker = brokerDao.read(form.getName());
		if(broker.getName()==null) throw new UserException("The address is not in the database");
		System.out.println(broker);
	}
	
	/*
	 * UPDATE
	 */
	public void updaterow(int commercial_broker_key, String name) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		brokerDao.update(commercial_broker_key, name);
	}
	
	/*
	 * DELETE
	 */
	public void deleterow(int commercial_broker_key) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		brokerDao.delete(commercial_broker_key);
	}
}
