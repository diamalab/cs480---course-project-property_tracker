package broker.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import broker.domain.Broker;

public class BrokerDao {
	/*
	 * INSERT OR ADD
	 */
	public void add(Broker broker) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "insert into broker values(?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setInt(1,broker.getCommercialBrokerKey());
		    preparestatement.setString(2,broker.getName());
		    preparestatement.setString(3,broker.getPhone());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * READ
	 */
	public Broker read(String name) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Broker broker = new Broker();
		try {
		
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
							+ "user=root&password=HetanN123!");
			
			
			String sql = "select * from broker where name=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			preparestatement.setString(1,name);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String theProperty = resultSet.getString("name");
		    	if(theProperty.equals(name)){
		    		broker.setCommercialBrokerKey(resultSet.getInt("commercial_broker_key"));
		    		broker.setName(resultSet.getString("name"));
		    		broker.setPhone(resultSet.getString("phone"));
		    	}
		    }
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		return broker;
	}
	
	/*
	 * UPDATE
	 */
	public void update(int commercial_broker_key, String name) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "update broker set name=? where commercial_broker_key=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setString(1, name);
			preparestatement.setInt(2, commercial_broker_key);
		    preparestatement.executeUpdate();
		    System.out.println("Row updated!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * DELETE
	 */
	public void delete(int commercial_broker_key) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "delete from broker where commercial_broker_key=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setInt(1, commercial_broker_key);
		    preparestatement.executeUpdate();
		    System.out.println("Row deleted!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
