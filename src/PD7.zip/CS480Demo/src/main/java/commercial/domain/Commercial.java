package commercial.domain;

public class Commercial {
	/*
	 * Correspond to the property table
	 */
	
	private int commercial_key;  // column name
	private String commercial_type;  // column name
	private int commercial_broker_key;  // column name

	// generate getters and setters

	public int getCommercialKey() {
		return commercial_key;
	}

	public void setCommercialKey(int commercial_key) {
		this.commercial_key = commercial_key;
	}

	public String getCommercialType() {
		return commercial_type;
	}

	public void setCommercialType(String commercial_type) {
		this.commercial_type = commercial_type;
	}

	public int getCommercialBrokerKey() {
		return commercial_broker_key;
	}

	public void setCommercialBrokerKey(int broker_key) {
		this.commercial_broker_key = broker_key;
	}
	
	@Override
	public String toString() {
		return "Commercial [ commercial_key=" + commercial_key + ", commercial_type="
				+ commercial_type + ", commercial_broker_key=" + commercial_broker_key +"]";
	}
}
