package commercial.service;

import commercial.dao.CommercialDao;
import commercial.domain.Commercial;
import user.service.UserException;

public class CommercialService {
	private CommercialDao commercialDao = new CommercialDao();
	
	/*
	 * INSERT
	 */
	public void insert(Commercial form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		commercialDao.add(form);
	}
	
	/*
	 * READ
	 */
	public void readrow(Commercial form) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Commercial commercial = commercialDao.read(form.getCommercialType());
		if(commercial.getCommercialType()==null) throw new UserException("This commercial type is not in the database");
		System.out.println(commercial);
	}
	
	/*
	 * UPDATE
	 */
	public void updaterow(int commercial_key, String commercial_type) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		commercialDao.update(commercial_key, commercial_type);
	}
	
	/*
	 * DELETE
	 */
	public void deleterow(int commercial_key) throws UserException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		commercialDao.delete(commercial_key);
	}
}
