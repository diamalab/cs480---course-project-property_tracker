package commercial.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import commercial.domain.Commercial;

public class CommercialDao {
	/*
	 * INSERT/ADD
	 */
	public void add(Commercial commercial) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "insert into commercial values(?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setInt(1,commercial.getCommercialKey());
		    preparestatement.setString(2,commercial.getCommercialType());
		    preparestatement.setInt(3,commercial.getCommercialBrokerKey());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * READ
	 */
	public Commercial read(String commercial_type) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Commercial commercial = new Commercial();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
							+ "user=root&password=HetanN123!");
			
			
			String sql = "select * from commercial where commercial_type=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			preparestatement.setString(1,commercial_type);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String theCommercial = resultSet.getString("commercial_type");
		    	if(theCommercial.equals(commercial_type)){
		    		commercial.setCommercialKey(resultSet.getInt("commercial_key"));
		    		commercial.setCommercialType(resultSet.getString("commercial_type"));
		    		commercial.setCommercialBrokerKey(resultSet.getInt("commercial_broker_key"));
		    	}
		    }
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		return commercial;
	}
	
	/*
	 * UPDATE
	 */
	public void update(int commercial_key, String commercial_type) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "update commercial set commercial_type=? where commercial_key=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setString(1, commercial_type);
			preparestatement.setInt(2, commercial_key);
		    preparestatement.executeUpdate();
		    System.out.println("Row updated!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * DELETE
	 */
	public void delete(int commercial_key) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "delete from commercial where commercial_key=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setInt(1, commercial_key);
		    preparestatement.executeUpdate();
		    System.out.println("Row deleted!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
