package property.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import property.domain.Property;

public class PropertyDao {
	/*
	 * INSERT/ADD
	 */
	public void add(Property property) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "insert into property values(?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setInt(1,property.getPropertyKey());
		    preparestatement.setString(2,property.getAddress());
		    preparestatement.setString(3,property.getCity());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * READ
	 */
	public Property read(String address) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Property property = new Property();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
							+ "user=root&password=HetanN123!");
			
			
			String sql = "select * from property where address=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			preparestatement.setString(1,address);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String theProperty = resultSet.getString("address");
		    	if(theProperty.equals(address)){
		    		property.setPropertyKey(resultSet.getInt("property_key"));
		    		property.setAddress(resultSet.getString("address"));
		    		property.setCity(resultSet.getString("city"));
		    	}
		    }
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		return property;
	}
	
	/*
	 * UPDATE
	 */
	public void update(int property_key, String address) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "update property set address=? where property_key=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setString(1, address);
			preparestatement.setInt(2, property_key);
		    preparestatement.executeUpdate();
		    System.out.println("Row updated!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/*
	 * DELETE
	 */
	public void delete(int property_key) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/property_tracker?"
					+ "user=root&password=HetanN123!");
			
			
			String sql = "delete from property where property_key=?";
			PreparedStatement preparestatement = connect.prepareStatement(sql);
			preparestatement.setInt(1, property_key);
		    preparestatement.executeUpdate();
		    System.out.println("Row deleted!");
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
