package property.service;

public class PropertyException extends Exception {

	public PropertyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PropertyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
