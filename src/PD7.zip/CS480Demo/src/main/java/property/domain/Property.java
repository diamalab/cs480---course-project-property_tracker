package property.domain;

public class Property {
	/*
	 * Correspond to the property table
	 */
	
	private int property_key;  // column name
	private String address;  // column name
	private String city;  // column name

	// generate getters and setters

	public int getPropertyKey() {
		return property_key;
	}

	public void setPropertyKey(int property_key) {
		this.property_key = property_key;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	@Override
	public String toString() {
		return "Property [ property_key=" + property_key + ", address="
				+ address + ", city=" + city +"]";
	}
}
